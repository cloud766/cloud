/**
 * 全选
 */
function selectAll(obj) {
  if ($(obj).is(':checked')) {
    $(".select-all-checkbox").prop("checked", true);
  } else {
    $(".select-all-checkbox").prop("checked", false);
  }
}
/**
* 通用删除
* @param  {[type]} obj [description]
* @return {[type]}     [description]
*/
function del(obj) {
  layer.confirm('确认删除选中项？', {
    btn: ['确定', '取消'] //按钮
  }, function () {
    var url = $(obj).data('url');
    var id = $(obj).data('id');
    $.ajax({
      url: url,
      data: { id: id },
      dataType: 'json',
      type: 'post',
      success: function (res) {
        if (res) {
          window.location.reload();
        } else {
          layer.msg('删除失败');
        }
      }
    })
  });
}

/**
* 通用批量删除
* @param  {[type]} obj [description]
* @return {[type]}     [description]
*/
function batchDel(obj) {
  var ids = [];
  $('.select-all-checkbox').each(function () {
    if ($(this).is(':checked')) {
      ids.push($(this).val());
    }
  });
  if (ids.length == 0) {
    layer.msg('未选中任何项');
    return
  }
  layer.confirm('确认删除选中项？', {
    btn: ['确定', '取消'] //按钮
  }, function () {
    var url = $(obj).data('url');
    $.ajax({
      url: url,
      data: { id: ids },
      dataType: 'json',
      type: 'post',
      success: function (res) {
        if (res) {
          window.location.reload();
        } else {
          layer.msg('删除失败');
        }
      }
    })
  });
}


function openIframe(obj) {
  var url = $(obj).data('url');
  var title = $(obj).data('title');
  var reload = $(obj).data('reload');
  layer.open({
    type: 2,
    title: title,
    shade: 0.8,
    area: ['60%', '60%'],
    content: url,
    end: function () {
      /*      $(".layui-layer-close").click();*/
      if (reload == 1) {
        location.reload();
      }
    }
  });
}

function clearRuntime(obj) {
  layer.confirm('确认清除缓存吗？', {
    btn: ['确定', '取消'] //按钮
  }, function () {
    var url = $(obj).data('url');
    $.ajax({
      url: url,
      dataType: 'json',
      type: 'post',
      success: function (res) {
        layer.msg(res.msg);
      }
    })
  });
}

function upload_callback(paths, names, sizes, input,multiple) {
  if (multiple == 0) {
    $('#' + input).val(paths);
    $('#p-' + input).attr('src', paths);
  } else {
    var str = '';
    for (var i = paths.length - 1; i >= 0; i--) {
      str += '<div class="input-group" style="margin-top:.5em;">';
      str += '<img src="';
      str += paths[i];
      str += '" class="img-responsive" width="100px">'
      str += '<em class="close" style="position:absolute; top: 0px; right: 5px;" title="删除这张图片" onclick="delImageList(this)">×</em></div>';
    }
    $('#g-' + input).append(str);
    var list = [];
    $('#g-' + input).find('img').each(function () {
      list.push($(this).attr('src'));
    })
    $('#' + input).val(list.join(','));
  }
}

function delImageList(obj) {
  var list = [];
  var parent_f = $(obj).parent();
  var parent_s = $(obj).parent().parent();
  var parent_t = $(obj).parents('.upload-image-list');
  parent_f.remove();
  parent_s.find('img').each(function () {
    list.push($(this).attr('src'));
  })
  parent_t.find('input').val(list.join(','));
}

function delImage(obj) {
  var _this = $(obj);
  _this.parents('.upload-image').find('input').val('');
  _this.parents('.upload-image').find('img').attr('src', '/static/addon/hx/images/nopic.jpg');
}

//校检是否为链接
function isURL(str) {
  var Expression = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
  var objExp = new RegExp(Expression);
  return objExp.test(str)
}
//校检是否为qq
function isQQ(qq) {
  qq = qq + "";
  var reg = /^[1-9]\d{4,12}$/;
  return reg.test(qq);
}
//校检是否为固定电话或者手机号
function isPHONE(phone) {
  var regMobilePhone = new RegExp(/^1[34578]\d{9}$/);
  console.log(regMobilePhone)
  var regTelephone = new RegExp(/^((0\d{2,3})-?)(\d{7,8})(-(\d{3,}))?$/);
  if (!(regMobilePhone.test(phone) || regTelephone.test(phone))) {
    return false;
  } else {
    return true;
  }
}
//校检是否为邮箱
function isEMAIL(email) {
  var reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return RegExp(reg).test(email);
}

/**
 * 异步提交表单
 * @param {form表单选择器} obj 
 * @param {保存链接} url 
 */
function formAjaxSubmit() {
  var index = layer.load(0, { shade: [0.1, '#fff'] });
  var obj = $('.ajax-form');
  var url = $(obj).attr('action');
  if (typeof (obj) == 'undefined' || typeof (url) == 'undefined') {
    return layer.msg('参数错误');
  }
  $.ajax({
    url: url,
    data: $(obj).serialize(),
    type: 'post',
    dataType: 'json',
    success: function (res) {
      layer.msg(res.msg);
      if (res.code && res.url) {
        location.href = res.url;
      } else if (res.code && !res.url) {
        location.reload();
      }
      if (res.code != 1) {
        $('input[name="__token__"]').val(res.data);
      }
      layer.close(index);   
    }
  })
}