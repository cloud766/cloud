<?php
namespace app\common\model;
use app\common\model\Base;

class Order extends Base
{

}