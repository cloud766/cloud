<?php
namespace app\common\model\yun;

use app\common\model\Base;

class YunSourceCodeAuth extends Base
{
	
}