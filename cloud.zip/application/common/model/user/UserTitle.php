<?php
namespace app\common\model\user;
use app\common\model\Base;

class UserTitle extends Base
{

}