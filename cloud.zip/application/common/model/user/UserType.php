<?php
namespace app\common\model\user;
use app\common\model\Base;

class UserType extends Base
{

}