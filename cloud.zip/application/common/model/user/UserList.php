<?php
namespace app\common\model\user;
use app\common\model\Base;
class UserList extends Base
{

}