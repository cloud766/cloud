<?php
return [
    'view_replace_str'       => [
       '__STATICS__' =>'/add/public/static/css', 
    ]
];