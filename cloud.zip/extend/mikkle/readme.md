
tp_wechat 微信类库
tp_wxpay  微信支付类库
TP5专用微信sdk下载及使用教程
https://www.kancloud.cn/mikkle/thinkphp5_study/447624

阿里大于
https://www.kancloud.cn/mikkle/thinkphp5_study/475226