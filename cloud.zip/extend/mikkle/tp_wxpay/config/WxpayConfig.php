<?php
/**
 * Created by PhpStorm.
 * User: Mikkle
 * QQ:776329498
 * Date: 2018/4/3
 * Time: 18:08
 */

namespace mikkle\tp_wxpay\config;


class WxpayConfig
{


}